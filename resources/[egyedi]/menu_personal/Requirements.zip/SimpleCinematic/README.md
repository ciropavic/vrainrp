# tota_cine

## Script that activates 2 black bars as a cinematic

@ Default button: [NUMPAD 5]

# Support and more free scripts on: https://discord.gg/9tspPPHEfM
