-- Set the language for all clients
i18n.setLang("en")

-- Enable or disable a optional resource
optional = {
	use_essentialmode = false,
	use_venomous = true
}