i18n.importData("en", {
	taxi_contact = "Llamada de taxi",
	welcome_message = "Presiona ~g~F7~w~ o usar ~g~/taxi~w~ para llamar a un taxi.",
	dispatch_message = "El taxista está en camino",
	drivers_busy = "Todos nuestros conductores están ocupados actualmente.",
	info_message = "Presiona ~INPUT_PICKUP~ para conducir como pasajero o ~INPUT_ENTER~ para robar el vehículo.",
	info_waypoint_message = "Seleccione su destino en el mapa, luego presione ~INPUT_PICKUP~ para comenzar.",
	taxi_dispatch = "El taxi está en camino."
})
