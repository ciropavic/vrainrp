# Changelog

## v2.0 - 22/10/2018
- Added support for [venomous-freemode](https://github.com/FiveM-Scripts/venomous-freemode).
- Improved resource performance.

## v1.1 - 22/02/2018
- Fixed better driving skills.

## v1.0 - 22/02/2018
- Players can spawn vehicles by pressing `F7` or using the chat command `/taxi`.
- Players can change the vehicle speed by pressing `E` or `SPACEBAR`.
- Added init payment system.